-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1328660)
addappid(1328661,0,"352894f27be6a4ac21ac6f2ee821bb07e969fbff77460f1d75958c2a03c1e097")
addappid(1328662,0,"bf55ab0596078c7dbcf3d210aaa944f07443b0dd087919e19255cd0d74c555eb")
addappid(1328663,0,"dd17dee6e6adca063fac5d7dd7b8887ff045615dc291f43e60c66f2d784f1ede")
addappid(1328664,0,"ff60f9f857207404386c355fd8ef3c3ded3ff4f8d02d2116491e653b42792f25")
addappid(1328665,0,"d301691944dcc891ff06689ce7be7f1c814012bff19a4d468a5d21aa36e37d13")
addappid(1328666,0,"940d6904a17d7e6cc2b11a6ec2081114ecfec5b231cdf215a414468b748aca83")
addappid(1328667,0,"8984a118acd7ad88e8e4e8c6d5f34456328e3ad4cd44d96453f769ec49969a8c")
addappid(1328668,0,"5551b293541f6c2ce9d514d303467fab8fd1a85d2791685b9dd77fc8c024d38a")
addappid(1328669,0,"fd8ffe56602361f32878ffbf6fed8180cf148d17f0b78adb6856759a94f7b3ba")
addappid(1378950)
addappid(1378951,0,"397141eca6997832db1ad1b4aee57661d380f51e95934aa7f22c9e1f3736347b")
addappid(1378952,0,"88dcd0c470ccf3fea446b2985a175204aa6e6655aacec31000e023828efc9c75")
