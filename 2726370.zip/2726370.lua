-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2726370)
addappid(2726371,0,"187ee6ed117535c8967bd54f73c9b349aa5b719bcd2ab59bc9d904a879f493ec")
