-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(851850)
addappid(1144580,0,"8fd5f4e52dfd3c1e7611db5e191e53d4931995ffc90b3bd645d232b2619400f7")
addappid(1144581,0,"bed8af793f7e46105b919a4e4486fdaa9cf381721c0442b4e28b768b244a5528")
addappid(1144582,0,"8371557f2f73862ab982c064abd9524accf2c75e90c9c49ce5885d2cf7324510")
addappid(1144640,0,"3bf489b8a002f962b62159c0b5e5978d50eeae4540ca214e7cd82edaca9caec7")
addappid(1144641,0,"622bd49a3e7e99cefa4f12c42054de891ccb428c2ed4c29b1a9fb1ae722c8ac9")
addappid(1144642,0,"757ef5805d47293f32980b95f06a283eebcd990e0a0557b1c72ee2453aa7becb")
addappid(1144643,0,"78c1157b70afe14c030801fb19d22d4503fc1365c242e2d1da1cc46366446207")
addappid(1144644,0,"a0748f203e51f369d8ebdea7e41d66d85ae8249cd8b938e5fa3efe574f7a4b8e")
addappid(1144645,0,"3b4424c34bd63ba6268480a9fb8b36990004627e01bd946ec444252b5113085c")
addappid(1144646,0,"579e3398336e5a072706ce2939246c4040c9c79936d78cebf1269495f7de6714")
addappid(851851,0,"fb1907fb7175034840a9685765e865e3f9c8b0aef43ba1cd125faca7a7e6e5ce")
