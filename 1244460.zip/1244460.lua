-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1244460)
addappid(1244461,0,"f32fa164f046ff769b0eb4c8ca8c0841866087c40db3edbec4d5f79b299e5fbe")
addappid(1336320)
addappid(1336321)
addappid(1336322)
addappid(1882470)
addappid(1966010)
addappid(2106800)
addappid(2177430)
addappid(2314000)
addappid(2492640)
addappid(2610980)
addappid(2806860)
addappid(2897800)
