-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(228983)
addappid(323470)
addappid(323471,0,"a92b27f33a671ba1ff67c80c0508d6f8d276ac2936d558fba95d8dc83e5b0765")
addappid(323473,0,"a9fc74b57e30b5d14ca436ebad3a4136d68941ba504102597afbb6410ec4c983")
addappid(336800)
addappid(344460)
addappid(344461)
addappid(344462)
addappid(344463)
addappid(362600)
