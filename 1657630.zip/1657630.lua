-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1657630)
addappid(1657631,0,"a37c1409dc2c7880fc988d25d9fa333438bab756f17f7d0fc27015c8ef2faed3")
