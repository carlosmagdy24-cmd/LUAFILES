-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3654560)
addappid(3654561,0,"6fc167060f8d59e04b1336aa831531599eba25b5d81a6d659408e1d69b65b456")
addappid(3802680)
