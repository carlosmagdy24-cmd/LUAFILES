-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1966720)
addappid(1966721,0,"b79233b678dae6d3f928ff9c6c7674d559427776a1337dee238773a4fec60949")
