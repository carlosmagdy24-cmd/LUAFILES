-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(71250)
addappid(71251,0,"772e98e07c55baadc311feeb6fbf98898744f6e56ec8220e4d35f56752bc6716")
addappid(228983)
