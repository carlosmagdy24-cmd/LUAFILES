-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3164500)
addappid(3164501,0,"81d0de07788de885787b0519b9dabf51618be6cba9124497decf572ac96624f4")
