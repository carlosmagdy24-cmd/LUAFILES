-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(237110)
addappid(237111,0,"2c086732018a2360a855d4d934af330f401e54794f4f8880fe41f9e0b724a1e3")
addappid(237112,0,"08ad2e11b65d254326f45d40a792b2687736ba990175d22c1fdaa77b103ae08d")
addappid(237113,0,"44163a4633f508f0f3fb88f3312505c73b08ef29c787c5743adf862d5f598f3d")
