-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3454980)
addappid(3454981,0,"a411f1c5ad0ff5f71b4e8aab564c7fd8fbd44ac3598a07480f2af377bcf65a9f")
