-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(686060)
addappid(686061,0,"632bb9334c4d72a84090a9998ec0bf0c8eac465df723928f022b40b6ff04119a")
