-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1222140)
addappid(1222141,0,"d87af32872df297ec519d0e79b6e0afc327b09048c3414622606b54efc46f519")
