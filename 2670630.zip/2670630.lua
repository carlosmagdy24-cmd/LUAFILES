-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2670630)
addappid(2670631,0,"72fc26c211612ffaa7b30cdfea152be9628668260d7f8c375980e0f96e445701")
addappid(2670632,0,"05a026749d66983d1a8b484cee9c7e2e320926d365ae5fe9f916ca8e96c00e4a")
