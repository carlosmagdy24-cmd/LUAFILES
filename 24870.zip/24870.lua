-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(24870)
addappid(24871,0,"d21bf6a450007944762201c63d2596658316d3daad66ca4b39269462dda788ff")
