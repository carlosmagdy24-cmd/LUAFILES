-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(319510)
addappid(319511,0,"1c9bdb805e961c88bff8090d7a3047fc4932948393b4a0d0939cc84ccbe542c4")
