-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(213610)
addappid(213611,0,"62f1345bc9ba1ad0629de28584b42ae616b50160113d7735b6eda7f0e9434117")
addappid(217900)
