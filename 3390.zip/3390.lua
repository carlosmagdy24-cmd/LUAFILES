-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3390)
addappid(3391,0,"7DC003180BE558F3AF5C201BADE330909BE77D0FFFF337D8A28C08768C7BF44E")
