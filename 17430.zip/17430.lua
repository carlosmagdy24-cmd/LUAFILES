-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(17430)
addappid(17431,0,"2c33da16f3e3ddd33ef8408ceda9d389413cbf88145d5fe09a25fc87c86f76bc")
addappid(17432,0,"fc36739c1ba9b15b9393ff7396a151a0cca05c4db57b458d11fd8b29b5924d11")
addappid(17433,0,"d5cdfa818361efc692228dac69bae63fa2b03f5cc86ef6fbbdd5b6a974146557")
addappid(17434,0,"c4b4da593d3a227971a4ab07aa170f2dff2167b1123443bb2571b50b9ec57591")
addappid(17435,0,"3b304a1132a82627b90da99c79f14a0047aabc77747794430c0156c575b95189")
addappid(17436,0,"1e2458f55e668c971e07a928fcb0d5c5db1ce9f748cce45f5ca71ef8bdbeba3c")
addappid(17437,0,"afc6e382d3d30cd675e7ad2dc45acc080e74162c27f9b7d8c65cd6d165ee1966")
