-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(13520)
addappid(13521,0,"12106f233eda3051d702308d07c2efca7d8ed17cea2e8e299d2d53b493f74be0")
addappid(13522,0,"f9f47d0f353a463edf451f5981f5209164fc32f151b7661faa285efcecb40a12")
addappid(13523,0,"ce8ce97d5b3a252efa8a9ea0ca53af3ab25fdb58dc01ad78ec25affb63929282")
addappid(13524,0,"d6e9bad7360a6c837afd3b532f46c327e784854b842adf75f04dc402c3f4b0e5")
addappid(13525,0,"57b1f9ec452ea4065a7e034ea9c54024757e8762bb278651ff1e76df9d317e16")
