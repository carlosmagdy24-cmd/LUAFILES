-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1790600)
addappid(1790601,0,"0721a07eb97ba7b4e59e31606ae9f0d67c66309cc467c5da1aa79a924c34e7d8")
addappid(2957460)
addappid(2957470)
addappid(2957480,0,"a8bbd2bdc3022cc2edc229e300b7583436b29d0e469662a8a277cf066798aa9f")
addappid(2957490,0,"1b1f85ab25eb92147de8a0c1531d9ed57f3e01cfd46c9bb37be377251c2d24cd")
addappid(2957500)
addappid(2957510)
addappid(2957520)
addappid(2963440)
addappid(2963450)
addappid(3310650)
addappid(3456600)
addappid(3456610)
addappid(3693250)
