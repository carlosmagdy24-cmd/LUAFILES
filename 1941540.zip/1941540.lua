-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1941540)
addappid(1941541,0,"47c1ea957b9ecc8662a117fa6b19eea01ed30ef06478a364110fe40afa4e9f0e")
addappid(3262000)
addappid(3269260)
addappid(3269270)
addappid(3269280)
