-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(221040)
addappid(221041,0,"0caaeec12d875fdc90b98bc67e35c76e8783d1dcd937cf35c40a9c24e3a6255d")
addappid(221042,0,"6a1e95acc180950d80167ccc4f012db4f7db4bd51e7816f2a00359383633a0bf")
addappid(221043,0,"02962ce3b494d53c57bd61a826554005fb222503e6c0060bd26e2cc579a50b77")
addappid(221044,0,"3dd6e6a48115cfd940f98db42ea65096953bfeb0f276b9920dac8b314ac80baf")
addappid(228580,0,"2424887018c8183e1490b98ae7786a90d24e24cb4c46a61c123930c78811ab97")
addappid(232490,0,"5576dff2e35fbdbe881daa2b22f385222145d8b2016560f8b83f15a8275b90b5")
addappid(232491,0,"ce138b6addc4abf27fdae757fee938ddc6cc2a0fc526ddb484c39f0b022293f3")
addappid(232510,0,"869fa259e1abbcfb8025c3df14623821df402e9d48f7fb24fba8c705c072a868")
addappid(232530,0,"9c993db672f4e320225bbfab9902a6fae2222734c907028fcb48eacd096a1578")
addappid(232550,0,"6affc24729a4aa5d5f02e24aaf03e5f0421bad2aa32c382f53bc5bc17778b3c7")
addappid(232570,0,"7272f338b0b950923367dc0643d2ef343c943311af70b29001da02e114e31c90")
addappid(232590,0,"de3eaf13095e5567e271b41dd9ccc82f4f25a75b3a7d360dc52164bd56b08b62")
addappid(235560)
addappid(236080,0,"7cb295a70dfbb52b081ad5da1559010aba2c5244a4eb50a78970b04a2da695eb")
