-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1546970)
addappid(1546971,0,"d6dfa8078e89488b58be9d37f6b0e04acd6535686db4037c9036f3ef6b552b84")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
