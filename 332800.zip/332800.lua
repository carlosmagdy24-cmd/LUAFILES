-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(332800)
addappid(332801,0,"a960d08a6fb0dab3a5d24ea11305bfa5068b866ad5d7d07cb60706321c1411f9")
