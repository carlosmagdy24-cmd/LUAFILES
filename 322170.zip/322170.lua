-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(322170)
addappid(322171,0,"73d09cfe5a697e2e5bf2a2591259e00c715e9dc3376d4a71ff7e915483be399d")
addappid(322172,0,"6accd00ac7da1a455e3e689eed217adcdcb14198e5dd23b1e553abbed6d5c38e")
