-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(21690)
addappid(21691,0,"b3ad2af3d25d179accc032ae7853c6f8a916bba21b5f0be9f11f22f0938110a4")
addappid(21692,0,"556f26dec9fcd54f1ecb0f2af6b1259a325a3eed959c0b242c83fa176c74971d")
addappid(21693,0,"a07f44cc54133c4921ca14f7014ea4a5fd0aa0dbc36d13f3d7abe5f3be00c564")
addappid(228981)
addappid(352000,0,"dba46409b51f3da1c7669a74a091ce7725eb5969705192edbb9ba3f9abd096d3")
