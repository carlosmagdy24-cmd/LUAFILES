-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(431960,0,"db983bc58a8cb46d89d1d70cc962cc733956e6124c4025a0c932f82b3c37144a")
addappid(431961,0,"62ac71786b9fbeecc473fccb8a14da04ea676371addd8820638ee6cddac8c344")
addappid(431966,0,"3217352ccc45b8943d6af58c14d359a38f2897bcf4d2f7f7eb117f79f1887fc4")
addappid(1790230,0,"28aacfb757c396f07f861f189a2c2ec78653123de2177c05f94a792d1a3c8bfd")
