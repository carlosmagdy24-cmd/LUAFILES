-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1245620)
addappid(1245621,0,"5f560fca048a138487e1e634a1e60693a7ad3ae7318c31731d147f16e093f10b")
addappid(1245623,0,"b27090a72caa5f3cf2e1f41a81c4bc1c422a6ac277e1cd3a6f1ea68200288d4b")
addappid(1245624,0,"e194ce5e5f83c427743781c1708c4bce6683d5d65521059f6e4ca64a8f36f3cd")
addappid(1799420)
addappid(1896300,0,"946e5c4e2c91a3ed363efc688218994f7fa6e8fdd56aa8b5752456d3b28e0543")
addappid(1896320,0,"de7086b709fdfc7d151bfce5d07509fd80a6c318a21e8fb1e820db5b1cda5860")
addappid(1922350)
addappid(2778580,0,"9f1556645ea8ef43529f920cf02a2682a6da5756b29e630ba376a0cde24e3908")
addappid(2778590)
addappid(2855520,0,"476eca9191866d6743aa7ad82d4d7ce1fcd5e0f0613f2f4b6559635d68f8c0e3")
addappid(2855530)
