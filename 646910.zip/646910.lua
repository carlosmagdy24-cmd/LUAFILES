-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(646910)
addappid(646911,0,"cc9f8bf715fb14e78193c2cdc408aabe45916e645246197afcc4f361b19eeb99")
addappid(702230)
addappid(702240)
addappid(702250)
addappid(889870)
addappid(889871)
addappid(889872)
addappid(889880)
addappid(889890)
addappid(999420)
addappid(999421)
addappid(1688450)
addappid(1688451)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
addappid(2183880)
addappid(2183881)
addappid(2183882)
addappid(2183883)
