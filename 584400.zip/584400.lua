-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(584400)
addappid(584401,0,"bb1637eb4c893c31ad5b560a6d53f01f665438e9f4deab4db1939b18d631a571")
addappid(845640)
