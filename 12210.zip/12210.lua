-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(12210)
addappid(12211,0,"155186d97af14c948ac35351ac345c108046167384eb2b898802f158bfd111b4")
addappid(12212,0,"63df369c3038e5c927f585fc81b41f5b669795976ac9af4d27a2add6c57733ca")
addappid(12213,0,"e927e10529530ef0a1798c945c7fea9d3a4bd8cb2bac061587c193afbe0dfeec")
addappid(12214,0,"f47f42a9df6c82ac4c134478cd1a0c95bdb32f686a3c4033ee8b9735c3999529")
addappid(12215,0,"70a582f0d5f9cbf610ccbac1a905c7d5c8f0f3b420412ee754779141d9a89e77")
addappid(12216,0,"ef7603bd0f512678f2832b71bcb340b950fd5d8ed5f52e0129300538727d1787")
addappid(12217,0,"050c5432482073005c36629ad7372baeafb6d1f63b6b8175936feb4ad8521d1c")
addappid(12218,0,"3446117408a17195591f5a98c1f64d2ca9a49dcdeb93a90fec8ceb63cb1cf249")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
