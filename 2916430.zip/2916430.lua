-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2916430)
addappid(2916431,0,"564c9e0805c5dec31aa2dd90a84b9b054479da085b32843dec67a4ef39a45eee")
