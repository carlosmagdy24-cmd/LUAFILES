-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1808500)
addappid(1808501,0,"9f7c91d4609594120c713e82bb64d0ebf15c63fdf6887bc2b3f8f20fcf58e005")
addappid(3948500)
addappid(3948510)
addappid(4048380)
