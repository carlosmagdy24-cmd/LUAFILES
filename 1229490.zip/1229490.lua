-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1229490)
addappid(1229491,0,"347634f48592b176da96c10b8afe6898527aa5c218d89930f9d6e5b6d5e7c8ba")
