-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2215390)
addappid(2215391,0,"d87a5534a048a1a7a81c896212cff7fa105e3104a74914bf1473552d72347211")
