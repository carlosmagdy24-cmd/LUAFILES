-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(388090)
addappid(388091,0,"76cfb5c74bbd068d0d29e42c39f08a9ee51592ab7b83920028404234ca2637cc")
