-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2287520)
addappid(2287521,0,"a7d107435e6dce4ba92250a6ae5b0df38e5adcb5254289c5c7633489a01afaa8")
