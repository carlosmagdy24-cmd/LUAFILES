-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(506610)
addappid(506611,0,"a9afd962f2b3b13615d00940a036fe77bf9bf5c0091de7c9474ac584c51d818f")
