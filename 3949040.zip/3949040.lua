-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3949040)
addappid(3949041,0,"98435e5f712a11c88e455130e718254b2745a33f7443b2034d634f54af0da031")
