-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(12200)
addappid(12201,0,"b02e549a49b9318ee8352042cb5cfe08a4d103eb6a7a3526c27e4e6ec86ed57b")
