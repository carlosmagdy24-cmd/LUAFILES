-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(354140)
addappid(354141,0,"ab90f669c8c840ed1677b657358f1ea2469927005c05b738dc6f1a08c8ae4d7e")
