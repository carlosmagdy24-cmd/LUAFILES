-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3506430)
addappid(3506431,0,"69da36b0d72b84caed88c36ce4770b1f85e1d7d0d2d5b44ad838eaa453fdff13")
