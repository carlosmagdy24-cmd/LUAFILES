-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(228985)
addappid(637100)
addappid(637101,0,"34786f5764c058209f977aa97cf340d54581cb6c4338c357eb60043ee04d250d")
addappid(715850,0,"fb6ff935866eacc93f05de899032058e28b39a7e52220a92da41dd648a1f005e")
addappid(715860,0,"0a67f95ed87c9b0f8195770fa6d31b367de0a1e12359bb23bc3c333b603a7a83")
addappid(715870,0,"532993be0075a75032142c0cb27061178bed95b2ad293b0b235d575833155ffc")
addappid(715890,0,"fb2f87dc682b73f5cda00cceaa7f79a6749e75794655f9f2a7b76ea4db365527")
addappid(715900,0,"808a3f18b9b4a57f270ae477194a037e9b36fb3bdc488797a3a2d0582dc20a2d")
addappid(715910,0,"07cd9314fd84a30f80f17d3cc8177c70d8c60f6a390b3a023c67ec50c4a5f393")
