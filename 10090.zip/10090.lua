-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(10090)
addappid(10091,0,"10ec612dbb207b40a95f3d87dfa3ff720d38ae05a9cacedba92b2c584451bf9b")
addappid(10092,0,"73dd3d3391cf0a30abe562035102c9d47b5d8b8ac6f48d8e574b5501926a5bbc")
addappid(10093,0,"2c33b9a6afc043bce38f9c0ba564194895df35c12a885b7bf4cfc6c2e1a18bd2")
addappid(10094,0,"7983e119dfd3586cc64677816aa111a598ba49e1d7e92c6b4db8cc9242ecdb86")
addappid(10095,0,"fe273171200d3e2271a7dddc4064869e3e4966799e710e805be043c2c30ad554")
addappid(10096,0,"e2dbc935ca2ae935ac53479fd77846231acb660baf06b3535d76abc4ccf61c81")
addappid(10097,0,"e416f35d0a6911df372411ff0e1dd8ecfec26424c41e0dfe24c4f5db9e1804d1")
