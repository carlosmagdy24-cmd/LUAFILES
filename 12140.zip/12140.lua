-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(12140)
addappid(12141,0,"852706f81744732c81de6bb29ee0c7bde48941cbdde1b270c0def608d8414827")
