-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(268910)
addappid(268911,0,"5f5e2d0105e9fcfbd0c7151658efd92af0181865fe434192f8e2c5d24d4940da")
addappid(268912,0,"6378a6f3808fd925e8fdc2cd115d7b60f1908a6dff6b5f6c1fb0af7f392db1e4")
addappid(1117850,0,"c40d10dcd40756563a4956777e0bb4333e48d34c00e2836edd3d5fdbc0eba095")
addappid(1117851,0,"1d08dafb023ed4a43d3def619d54ace53b3b4bced035e744da83b4449f26cac7")
