-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1922560)
addappid(1922561,0,"1e43c639ac6e795304b48885b326acfcd86d6f53c39fd803abd36e6770742457")
addappid(1922562,0,"d32055c3f5e9d8642d1bebfd77315df84e7842523b7bd69efbb2e0c329d51695")
addappid(1922563,0,"711bce276c639967f8ab97b7619c54778302a3370edcdddb7e2bde31c6ec3ac5")
addappid(1922564,0,"a8e69ead80983a149b6696eaf6cc65cd2b399f194c94f97b47af619c99a6b26a")
addappid(1922565,0,"a48c1b714c51b3ecedecdb2d8f18e37a9c31177340d3b3221504370a575fcee9")
addappid(1922566,0,"e4056bac61de386a1acab287a76375a0d58940391494f572613bcedea407c17f")
addappid(1922567,0,"6ea3881bdead8fd6ae22deffa8561f30d3a0b4d89dc58c1ba3fbeba9ea7c82d0")
addappid(1922568,0,"0636e5895910391007947a54c5490128989fa679d8a4983028e476c4d4e00c30")
addappid(1922569,0,"6c0dca675dbd318fd4433dde3ca733de100108fb3e75c4818e9d1273eebb2c64")
addappid(1922590)
