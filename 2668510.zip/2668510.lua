-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
addappid(2668510)
addappid(2668511,0,"839eae6ac7edb75331c27732d207b339d78db2f2bd634989b08bd602a4c5983b")
addappid(2668512,0,"ba1f0d8d7f0e02e8659bdd8d6a7738133974941d2da9845ae59a4f0fa456d801")
addappid(2668513,0,"af2b732e108f2a10ed375b7042e3aa1cbdf57dc59dc07c303a7d9d31e81b9c59")
