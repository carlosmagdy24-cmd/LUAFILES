-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2399830)
addappid(2399831,0,"320e0bcc46f1e7d88e18488c73990878eedbc06c3284015e1d0af97abe143e23")
addappid(2827030,0,"ca47571a30440cd0d827bee6a57a945cf56d25fd4dbc19435d608994b021302a")
addappid(2849450,0,"06a4aa068a1a3940e0c7eff34508ad6474806f4b46520ef9ea12b4b7f77a3d0e")
addappid(2881150)
addappid(2972680)
addappid(3059650,0,"84b1a413568c28ea0226bbd983fbf08741ead907cc7cd9cdd447056405850bd2")
addappid(3282470)
addappid(3349320,0,"e0cbc7f932b6b5ffa7e36b9fe8ccf5b2317d5073f520b8a357a7bb8e32d7a181")
addappid(3483400,0,"8f2706fe64f86426091cbb9a23dedbc3ec0c53a78877abb9b549edded5f436ea")
addappid(3571730)
addappid(3583650)
addappid(3675020,0,"5028ee914f2c74aba43cc91d7f2f49fd5ad0ec96dcb76372ed26deec22b0e88c")
addappid(3720100)
addappid(3720200)
addappid(3982300)
addappid(3982310)
