-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(476600)
addappid(476601,0,"831cdecf19668b10b3209e2889d22d39db73940b21ac18a35007bf587bf931cf")
addappid(476602,0,"613f95c421e8081508651a80293faf846ea81e6f1e1a5c27398220ce12d6e2cb")
addappid(476603,0,"ac9dcb534d5b6076fc179a3038eb8ad8aa079fa1acbf3e5db83f0d5413b97c14")
addappid(476604,0,"9d96074527f4d14f2ae748dc241d6c5a08ff8a1682b022128aca9a5e96479503")
addappid(476605,0,"dbac9cb02a7787a7511ff155d3a36b55a44cfcdc2b4444fa0f38965f531f57a5")
addappid(476606,0,"4b7da74018117af93f3b22f8d7d146f9b3220ec37bdfb3ee8a959bbee51d6b1f")
