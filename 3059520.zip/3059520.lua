-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3059520)
addappid(3059521,0,"69b468d1904c13ad60ff37077c6c6350439f3e70a1df3afcfc075f41325f6b8b")
addappid(3059522,0,"136b91fa8f220638f0a95077f481dbcb9c6f8d5a936401ec0222ddc2cc73de68")
addappid(3059523,0,"0fefd33650cc16731c9eaa7582b567f5ab2e1dfe22480ba457f704740cb59275")
addappid(3059524,0,"0f267a629c6d00a85bbea9fcadd7a8031d68da2504ea8e24821967b15c695e01")
addappid(3335200)
addappid(3335210)
addappid(3335220)
addappid(3335250)
addappid(3335260)
addappid(3493790)
addappid(3493820)
addappid(3493830)
addappid(3546340)
addappid(3601380)
