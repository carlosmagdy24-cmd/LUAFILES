-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2638370)
addappid(2638371,0,"8852cf8d7bc2edf25ef5fa623e3a6811b710f8c4e6ed3d59de3db7f7a9776210")
