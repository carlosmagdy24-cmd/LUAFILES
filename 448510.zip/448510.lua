-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(448510)
addappid(448511,0,"d54ea6782642b416a2c5587f03ed3c9b7cbf6098565dca9cd91325ac1c79e750")
addappid(530060,0,"ddca5a86b69fd74aec04867274a9171d22a319ca1efe116d60ad195e840710c2")
