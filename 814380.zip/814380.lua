-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(814380)
addappid(1039230,0,"fdf0783fc1f1f3ee832c2912beffe0982e4f6d2abb1b63c8266fade7ad7f4493")
addappid(814381,0,"84db6d0cd0648c885d471541b83416e460f07ad6b71e1b86b2fa26926514d874")
addappid(814382,0,"742e0660742d90e8f827db3e00bcbf594970e97e76f8fb90ec74a54562ef5502")
addappid(814383,0,"3f8022efca09175e6bef77385ece0b5693e94d829d50baab66f9e249b996992b")
addappid(814385,0,"8689daaad42496510eb7b2fc6f6de095af54aae85e481998eb4746d2fad6b9af")
