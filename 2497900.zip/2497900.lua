-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2497900)
addappid(2497901,0,"42d0e96d7b5440cf0b812b5ec843e2e437e28ba281e46830a2d2d7ec65c2a030")
