-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(19900)
addappid(19901,0,"c21afb5887d399bed13311cbcefc03dbe5552ad116a12ecbe56fe4ae069e862c")
addappid(19902,0,"91591bb723c176e6d6afae850f9b4047010247d4a1a26008b409bef474d8cdd3")
addappid(19903,0,"d3abd6b840eae547bd34f32d7928494304327351db5704f3c6545053171f1f8f")
addappid(19904,0,"37d01ab596c4414c076ea853e54b112a25b1c2448add301d8ec1f5680d289f4c")
addappid(19905,0,"5d235dcc7cce0c0dadc4f74567d15b59f33b016449585a9403b5eb7053451a61")
addappid(19906,0,"444337f5a842722ec48294b7091394cd18c63a0a00837fc2d045990a613d6f65")
addappid(21960)
addappid(21961,0,"d941019d3d54cf464a67976dbb0dd0b5c26630cae2f4a5ed03e2d71b7f084740")
