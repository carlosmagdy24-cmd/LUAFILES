-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(229007)
addappid(1243830)
addappid(1243831,0,"ee4fef3dceab1e96eb608bde52106366ade46c83bf1db1432b02b5f5e3d9c858")
addappid(1528250)
