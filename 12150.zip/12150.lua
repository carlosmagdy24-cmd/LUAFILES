-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(12150)
addappid(12151,0,"7d78588a024003c4989d9dc5a5d86d60223495c8c86c8d2b9591278d0e1e112d")
