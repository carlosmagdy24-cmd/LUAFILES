-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(229007)
addappid(2022670)
addappid(2022671,0,"f2c1f41d9127af994a3cd878921ff5b89db85334ee15711d98ecac202e0b2c54")
addappid(2376680)
addappid(2376681)
addappid(2376682)
addappid(2376683)
addappid(2376684)
addappid(2376685)
addappid(2376686)
addappid(2378680)
addappid(2504600)
addappid(2549530)
