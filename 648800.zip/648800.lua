-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(648800)
addappid(648801,0,"69b674ffb72cbe77ce081b29070056279accc29956cad5d38d31e0d3e2090632")
