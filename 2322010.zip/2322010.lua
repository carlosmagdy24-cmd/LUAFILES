-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2322010)
addappid(2322011,0,"78758c85a2a8b04770fb4fe430ac7a215a959b72e496d94f6a0ec5ac38066f49")
addappid(2974320)
addappid(2974330)
addappid(2974340)
